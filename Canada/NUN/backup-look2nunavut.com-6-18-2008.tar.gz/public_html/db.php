<?php
    $DATABASE_SERVER = ':/var/lib/mysql/mysql.sock';
    $DATABASE_NAME   = 'nun_nun';
    $DATABASE_USER   = 'nun_dub';
    $DATABASE_PASSWORD = 'gabe0810';
?>
