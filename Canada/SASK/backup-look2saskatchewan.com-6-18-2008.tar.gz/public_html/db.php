<?php
    $DATABASE_SERVER = ':/var/lib/mysql/mysql.sock';
    $DATABASE_NAME   = 'sask_sask';
    $DATABASE_USER   = 'sask_dub';
    $DATABASE_PASSWORD = 'gabe0810';
?>
