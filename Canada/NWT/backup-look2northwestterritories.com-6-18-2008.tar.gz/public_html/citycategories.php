<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" href="/dub.css" type="text/css"/>
<title>Northwest Territories Business | City Categories</title>

<script language="JavaScript">
function blockError(){return true;}
window.onerror = blockError;
</script>
</head>

<body>
<center>


<div id="wrap">
   	<div id="header" align="center">
	<img src="/look2yellowpages1.jpg" align="left" alt="Northwest Territories business">
	<h1><strong>Northwest Territories</strong></h1>
	</div>
<div id="content">	
  
  


<?PHP

echo "       <div align=\"center\">&nbsp;$c Business categories \n";        
echo "        </div>\n";
?>
<div id="avmenu">


<center>
<script type="text/javascript"><!--
google_ad_client = "pub-1757895371029345";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = "120x600_as";
google_ad_type = "text";
//2007-02-27: look2#800000sky
google_ad_channel = "9136936419";
google_color_border = "ffffff";
google_color_bg = "ffffff";
google_color_link = "800000";
google_color_text = "000000";
google_color_url = "000000";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>
</div>

<div id="extras">  	
<center>
<script type="text/javascript"><!--
google_ad_client = "pub-1757895371029345";
google_ad_width = 120;
google_ad_height = 600;
google_ad_format = "120x600_as";
google_ad_type = "text";
//2007-02-27: look2#800000sky
google_ad_channel = "9136936419";
google_color_border = "ffffff";
google_color_bg = "ffffff";
google_color_link = "800000";
google_color_text = "000000";
google_color_url = "000000";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

<script type="text/javascript"><!--
google_ad_client = "pub-1757895371029345";
google_ad_width = 125;
google_ad_height = 125;
google_ad_format = "125x125_as_rimg";
google_cpa_choice = "CAAQsPGkgwIaCPmCQ1KFDGpqKOjKrIMB";
google_ad_channel = "5547787778";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>
</div>	

<div align="center">    
  <?php
echo "       <b><font face=\"Verdana\" color=\"#000000\" size=\"2\">Search $c, Northwest Territories Business Listings</font> </b><br>\n";
      
echo " <center>     <form style=\"margin: 0px\" action=\"cq.php\" method=get> \n";
echo "              <input name=c type=hidden value=\"$c\">\n";
echo "              <input size=35 name=q type=text value=\"\">\n";
echo "              <input type=submit value=\"Search $c YP\"></center></form>\n";
    
?>  
</div>    
    
    
   
<div align="center" style="color:#000000;">
  <strong>Northwest Territories Business Categories</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><a href="/" style="color:#800000">Home</a></strong>
  </div>
  
  <table align="center">
  <tr>
    
    <td width="250" valign="top" style="font-size:9px">

<?php
echo" <a href=\"cq.php?c=$c&q=Aboriginal Organizations.htm\">Aboriginal Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Accountants.htm\">Accountants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Accountants Public.htm\">Accountants Public</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Accounting and Tax Services.htm\">Accounting and Tax Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Activity Centers.htm\">Activity Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Actuaries.htm\">Actuaries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Acupuncture and Acupressure.htm\">Acupuncture and Acupressure</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Addiction Information and Treatment Centers.htm\">Addiction Information and Treatment Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Adoption Agencies and Services.htm\">Adoption Agencies and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Adult Education School.htm\">Adult Education School</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Advertising Agencies and Counselors.htm\">Advertising Agencies and Counselors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Advertising Radio and Audio.htm\">Advertising Radio and Audio</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Agricultural Consultants.htm\">Agricultural Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Air Cleaning and Purifying Equip.htm\">Air Cleaning and Purifying Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Air Conditioning Contractors.htm\">Air Conditioning Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Air Purification Equip and Systems.htm\">Air Purification Equip and Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aircraft Charter Rental and Leasing Svc.htm\">Aircraft Charter Rental and Leasing Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aircraft Dealers and Distributors.htm\">Aircraft Dealers and Distributors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aircraft Equip and Parts and Supls.htm\">Aircraft Equip and Parts and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aircraft Mfrs.htm\">Aircraft Mfrs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aircraft Servicing.htm\">Aircraft Servicing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Airline Services.htm\">Airline Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Airline Ticket Agencies.htm\">Airline Ticket Agencies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Airport Equip and Supls.htm\">Airport Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Airport Transportation and Parking Service.htm\">Airport Transportation and Parking Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Airports.htm\">Airports</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Alcoholism and Drug Abuse Information and Treatment Centers.htm\">Alcoholism and Drug Abuse Information and Treatment Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=All Terrain Vehicles.htm\">All Terrain Vehicles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Alternators Generators and Starters Sales and Service.htm\">Alternators Generators and Starters Sales and Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ambulance Service.htm\">Ambulance Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Amusement Centers.htm\">Amusement Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Animal Boarding and Grooming.htm\">Animal Boarding and Grooming</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Animal Breeders and Dealers.htm\">Animal Breeders and Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Antique Repairing and Restoring.htm\">Antique Repairing and Restoring</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Antique Reproductions.htm\">Antique Reproductions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Antiques.htm\">Antiques</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Apartment Rental Agencies.htm\">Apartment Rental Agencies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Apartments and Buildings.htm\">Apartments and Buildings</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Appliances Major.htm\">Appliances Major</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Appliances Service and Repair.htm\">Appliances Service and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Appliances Small.htm\">Appliances Small</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Appliances Used.htm\">Appliances Used</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aquariums and Supplies.htm\">Aquariums and Supplies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Archery Equip and Supls.htm\">Archery Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Architects.htm\">Architects</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Architectural Illustrators.htm\">Architectural Illustrators</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Armored Car Svcs.htm\">Armored Car Svcs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aromatherapy Services.htm\">Aromatherapy Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Art Galleries.htm\">Art Galleries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Art Restoration and Conservation.htm\">Art Restoration and Conservation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Art School.htm\">Art School</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Artists.htm\">Artists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Artists Commercial and Graphic.htm\">Artists Commercial and Graphic</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Artists Fine Arts.htm\">Artists Fine Arts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Arts and Crafts Shops.htm\">Arts and Crafts Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Arts Organizations and Information.htm\">Arts Organizations and Information</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Asbestos Abatement and Removal Svcs.htm\">Asbestos Abatement and Removal Svcs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Astrologers Psychic Consultants Etc.htm\">Astrologers Psychic Consultants Etc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Athletic Organizations and Clubs.htm\">Athletic Organizations and Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Attorneys.htm\">Attorneys</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auctioneers and Auction Houses.htm\">Auctioneers and Auction Houses</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Alarms and Security Systems.htm\">Auto Alarms and Security Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Antique and Classic.htm\">Auto Antique and Classic</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Body Repair and Paint.htm\">Auto Body Repair and Paint</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Customizing and Restoration.htm\">Auto Customizing and Restoration</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Dealers Used Cars.htm\">Auto Dealers Used Cars</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Glass.htm\">Auto Glass</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Inspection Services.htm\">Auto Inspection Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Lubricating and Oil Services.htm\">Auto Lubricating and Oil Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Performance Race and Sport Equip.htm\">Auto Performance Race and Sport Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Repair.htm\">Auto Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Auto Wrecking and Recycling.htm\">Auto Wrecking and Recycling</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers.htm\">Automobile Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Chrysler-Plymouth.htm\">Automobile Dealers Chrysler-Plymouth</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Pontiac.htm\">Automobile Dealers Pontiac</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Saturn.htm\">Automobile Dealers Saturn</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Subaru.htm\">Automobile Dealers Subaru</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Toyota.htm\">Automobile Dealers Toyota</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Dealers Volkswagen.htm\">Automobile Dealers Volkswagen</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Emission Testing.htm\">Automobile Emission Testing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automobile Renting and Leasing.htm\">Automobile Renting and Leasing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automotive Air Conditioners.htm\">Automotive Air Conditioners</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automotive Brokers and Auctions.htm\">Automotive Brokers and Auctions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Automotive Radios and Stereo Systems.htm\">Automotive Radios and Stereo Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Aviation Organizations.htm\">Aviation Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Awnings and Canopies and Supls.htm\">Awnings and Canopies and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Baby Furniture.htm\">Baby Furniture</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Baby Sitting Services.htm\">Baby Sitting Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bakeries.htm\">Bakeries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Balloons and Helium.htm\">Balloons and Helium</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Balloons Retail.htm\">Balloons Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ballrooms and Dance Clubs.htm\">Ballrooms and Dance Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bankruptcies Trustees.htm\">Bankruptcies Trustees</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bankruptcy Services.htm\">Bankruptcy Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Banks.htm\">Banks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Banks Loans and Mortgage.htm\">Banks Loans and Mortgage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Banquet Facilities.htm\">Banquet Facilities</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bar and Grills.htm\">Bar and Grills</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Barbecue Equip and Supls.htm\">Barbecue Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Barber and Beauty Shops.htm\">Barber and Beauty Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Barbers.htm\">Barbers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Barbers and Cosmetologists Hair Stylists.htm\">Barbers and Cosmetologists Hair Stylists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Barbers Equipment and Supplies.htm\">Barbers Equipment and Supplies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bartender and Host Services.htm\">Bartender and Host Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Batting Cages and Ranges.htm\">Batting Cages and Ranges</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beauty Consultants.htm\">Beauty Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beauty Institutes.htm\">Beauty Institutes</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beauty Salons.htm\">Beauty Salons</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bed and Breakfast.htm\">Bed and Breakfast</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bee Keepers and Bee Removal Svc.htm\">Bee Keepers and Bee Removal Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beer and Ale Retail.htm\">Beer and Ale Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beer and Beverage.htm\">Beer and Beverage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beer and Wine Stores.htm\">Beer and Wine Stores</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beer Dispensing and Cooling Equip Wholesale.htm\">Beer Dispensing and Cooling Equip Wholesale</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beer Taverns.htm\">Beer Taverns</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Beverage Mfrs.htm\">Beverage Mfrs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bicycle Accessories.htm\">Bicycle Accessories</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bicycle Renting.htm\">Bicycle Renting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bicycle Sales Service and Rentals.htm\">Bicycle Sales Service and Rentals</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bicycles.htm\">Bicycles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Billiard and Pool Parlors.htm\">Billiard and Pool Parlors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Billiard Equip and Supls.htm\">Billiard Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bingo.htm\">Bingo</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bingo Equip and Supls.htm\">Bingo Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Binoculars and Telescopes.htm\">Binoculars and Telescopes</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bird Barriers Repellents and Controls.htm\">Bird Barriers Repellents and Controls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bird Feeders Houses and Supls.htm\">Bird Feeders Houses and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Blacksmiths.htm\">Blacksmiths</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Blasting Contractors.htm\">Blasting Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Blood Banks and Centers.htm\">Blood Banks and Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Blue Printing.htm\">Blue Printing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat and Yacht Cleaning and Detailing.htm\">Boat and Yacht Cleaning and Detailing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Builders and Wholesalers.htm\">Boat Builders and Wholesalers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Charters.htm\">Boat Charters</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Dealers.htm\">Boat Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Equip and Svcs Boat Repairing.htm\">Boat Equip and Svcs Boat Repairing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Excursion and Sightseeing Trips.htm\">Boat Excursion and Sightseeing Trips</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Renting and Leasing.htm\">Boat Renting and Leasing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boat Transporting.htm\">Boat Transporting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Body Art and Piercing.htm\">Body Art and Piercing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bonds Surety and Fidelity.htm\">Bonds Surety and Fidelity</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Book Dealers Comic.htm\">Book Dealers Comic</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Book Dealers Retail.htm\">Book Dealers Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Book Dealers Used and Rare.htm\">Book Dealers Used and Rare</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bookkeeping Services.htm\">Bookkeeping Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Books.htm\">Books</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Boot and Shoe Repair.htm\">Boot and Shoe Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bottle Returns.htm\">Bottle Returns</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bowling Centers.htm\">Bowling Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Brake Svc and Repair.htm\">Brake Svc and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Brass and Brass Products.htm\">Brass and Brass Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Breast Feeding Information.htm\">Breast Feeding Information</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Breweries.htm\">Breweries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Brewers Equip and Supls.htm\">Brewers Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bridal Gown Cleaning and Preservation Svce.htm\">Bridal Gown Cleaning and Preservation Svce</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bridal Shops.htm\">Bridal Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bridge Clubs and Instruction.htm\">Bridge Clubs and Instruction</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bronzing and Preserving.htm\">Bronzing and Preserving</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Builders and Contractors.htm\">Builders and Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building and House Moving and Raising.htm\">Building and House Moving and Raising</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building and Property Maintenance.htm\">Building and Property Maintenance</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building Cleaning Exterior.htm\">Building Cleaning Exterior</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building Consultants.htm\">Building Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building Inspections.htm\">Building Inspections</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Building Materials and Supls.htm\">Building Materials and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bulldozing Contractors.htm\">Bulldozing Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Burglar Alarm Systems.htm\">Burglar Alarm Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Burglar Alarm Systems Residential.htm\">Burglar Alarm Systems Residential</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bus Charter and Rental Service.htm\">Bus Charter and Rental Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Bus Transportation.htm\">Bus Transportation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business and Economic Development.htm\">Business and Economic Development</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business and Trade Organizations.htm\">Business and Trade Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business Centers.htm\">Business Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business Colleges.htm\">Business Colleges</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business Consultants and Advisors.htm\">Business Consultants and Advisors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business Development.htm\">Business Development</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Business Svcs.htm\">Business Svcs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cabinets and Cabinet Makers.htm\">Cabinets and Cabinet Makers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cabins.htm\">Cabins</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cable Contractors and Service.htm\">Cable Contractors and Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cable Television Companies and Services.htm\">Cable Television Companies and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cafe and Restaurant.htm\">Cafe and Restaurant</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Calligraphers.htm\">Calligraphers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Campers.htm\">Campers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Campground and Recreational Vehicle Parks.htm\">Campground and Recreational Vehicle Parks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Campgrounds.htm\">Campgrounds</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Camping Equip and Supls.htm\">Camping Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Camps.htm\">Camps</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Canoe Trip Outfitters.htm\">Canoe Trip Outfitters</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Canoes and Kayaks.htm\">Canoes and Kayaks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Canoes and Kayaks Sales and Rentals.htm\">Canoes and Kayaks Sales and Rentals</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Canvas Goods and Products.htm\">Canvas Goods and Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Career and Vocational Counseling.htm\">Career and Vocational Counseling</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cargo and Freight Containers.htm\">Cargo and Freight Containers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Carpenters.htm\">Carpenters</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Carpet.htm\">Carpet</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Carpet and Rug Cleaners.htm\">Carpet and Rug Cleaners</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Carpet and Rug Cleaning Equip Rental.htm\">Carpet and Rug Cleaning Equip Rental</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Carpet and Rug Installation.htm\">Carpet and Rug Installation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cartage.htm\">Cartage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Casino Organizations.htm\">Casino Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Casinos Gambling.htm\">Casinos Gambling</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Caterers.htm\">Caterers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Caterers Equip and Supls.htm\">Caterers Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cd Rom Production Services.htm\">Cd Rom Production Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cd-Rom and Dvd Services.htm\">Cd-Rom and Dvd Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cellular and Mobile Telephone Equip and Supls.htm\">Cellular and Mobile Telephone Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cellular and Mobile Telephone Service.htm\">Cellular and Mobile Telephone Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cement.htm\">Cement</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cemeteries and Memorial Parks.htm\">Cemeteries and Memorial Parks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Chambers Of Commerce.htm\">Chambers Of Commerce</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Charitable and Non-Profit Organizations.htm\">Charitable and Non-Profit Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Charters and Tours.htm\">Charters and Tours</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Chauffeur Service.htm\">Chauffeur Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Check Advance Service.htm\">Check Advance Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Check Cashing Svc.htm\">Check Cashing Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Child Care Facilities.htm\">Child Care Facilities</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Child Care Service.htm\">Child Care Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Child/day Care Equip and Supls.htm\">Child/day Care Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Children and Family Entertainment.htm\">Children and Family Entertainment</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Children and Infants Wear.htm\">Children and Infants Wear</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Childrens Services and Activities Information.htm\">Childrens Services and Activities Information</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Chimney Cleaning and Sweeps.htm\">Chimney Cleaning and Sweeps</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Church and Religious Associations and Organizations.htm\">Church and Religious Associations and Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cigar Cigarette and Tobacco Dealers.htm\">Cigar Cigarette and Tobacco Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cisco Systems Computers.htm\">Cisco Systems Computers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Civil Defense Agencies.htm\">Civil Defense Agencies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cleaners Dry Cleaning.htm\">Cleaners Dry Cleaning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cleaning Services Household and Commercial.htm\">Cleaning Services Household and Commercial</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clergy.htm\">Clergy</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clinics and Medical Centers.htm\">Clinics and Medical Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clinics Dental.htm\">Clinics Dental</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clocks Service and Repair.htm\">Clocks Service and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clowns.htm\">Clowns</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clubs Fraternal.htm\">Clubs Fraternal</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clubs Social Service.htm\">Clubs Social Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Clubs Youth.htm\">Clubs Youth</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Coffee Houses and Cafes.htm\">Coffee Houses and Cafes</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Coin Dealers and Supls.htm\">Coin Dealers and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Collectibles.htm\">Collectibles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Collection Agencies and Systems.htm\">Collection Agencies and Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Collision Service.htm\">Collision Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Commercial and Industrial Cleaning.htm\">Commercial and Industrial Cleaning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Commodity Brokers.htm\">Commodity Brokers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Community Buildings.htm\">Community Buildings</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Community Centers.htm\">Community Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Community Development.htm\">Community Development</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Community Organizations.htm\">Community Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Community Service.htm\">Community Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Compact Discs Tapes and Records.htm\">Compact Discs Tapes and Records</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computer Sales and Services.htm\">Computer Sales and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers and Equip.htm\">Computers and Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers and Equip Dealers Used.htm\">Computers and Equip Dealers Used</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers and Equipment Repairs and Maintenance.htm\">Computers and Equipment Repairs and Maintenance</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Advertising Internet.htm\">Computers Advertising Internet</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Cable and Wire Installation.htm\">Computers Cable and Wire Installation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Data Recovery.htm\">Computers Data Recovery</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Graphics and Animation.htm\">Computers Graphics and Animation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Instruction and Training.htm\">Computers Instruction and Training</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Networks.htm\">Computers Networks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Security Svcs.htm\">Computers Security Svcs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Software and Hardware.htm\">Computers Software and Hardware</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Svc and Consultants.htm\">Computers Svc and Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Computers Telephony.htm\">Computers Telephony</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concierge Service.htm\">Concierge Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Contractors.htm\">Concrete Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Driveways and Sidewalks.htm\">Concrete Driveways and Sidewalks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Grinding and Finishing.htm\">Concrete Grinding and Finishing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Pumping Svc.htm\">Concrete Pumping Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Ready Mix.htm\">Concrete Ready Mix</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Concrete Repairing Restoration Sealing and Cleaning.htm\">Concrete Repairing Restoration Sealing and Cleaning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Condominiums Renting and Leasing.htm\">Condominiums Renting and Leasing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Conservation Resources and Services.htm\">Conservation Resources and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Construction Companies.htm\">Construction Companies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Construction Consulting and Management.htm\">Construction Consulting and Management</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Construction Management Consultants.htm\">Construction Management Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Construction Materials.htm\">Construction Materials</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Consulates and Other Foreign Govt Reps.htm\">Consulates and Other Foreign Govt Reps</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Contact Lens Prescriptions Filled.htm\">Contact Lens Prescriptions Filled</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Contractors Windows.htm\">Contractors Windows</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Convenience Stores.htm\">Convenience Stores</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Convention and Meeting Planning Services.htm\">Convention and Meeting Planning Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cooking School.htm\">Cooking School</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Copying and Duplicating Services.htm\">Copying and Duplicating Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cosmetics and Perfumes.htm\">Cosmetics and Perfumes</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Costumes Masquerade and Theatrical.htm\">Costumes Masquerade and Theatrical</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cottages Prefabricated.htm\">Cottages Prefabricated</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Counselors.htm\">Counselors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Country Clubs.htm\">Country Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Credit and Debt Counseling Services.htm\">Credit and Debt Counseling Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Crime Stoppers.htm\">Crime Stoppers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Crisis Intervention Services.htm\">Crisis Intervention Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cruise Agents.htm\">Cruise Agents</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Curling Rinks.htm\">Curling Rinks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Currency Exchanges.htm\">Currency Exchanges</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Customs Brokers.htm\">Customs Brokers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Cutting Water Jet.htm\">Cutting Water Jet</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dairy Farms.htm\">Dairy Farms</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dance Instruction.htm\">Dance Instruction</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dance Studios.htm\">Dance Studios</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Darts.htm\">Darts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Day Care Centers.htm\">Day Care Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Day Care Nursery Schools and Kindergartens.htm\">Day Care Nursery Schools and Kindergartens</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Demolition and Wrecking Contractors.htm\">Demolition and Wrecking Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dentists.htm\">Dentists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Department Stores.htm\">Department Stores</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Diamonds.htm\">Diamonds</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dieticians.htm\">Dieticians</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Disabled Services and Organizations.htm\">Disabled Services and Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Divers Equip Supls and Excursions.htm\">Divers Equip Supls and Excursions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Divers Instruction Sales and Service Equip and Supls.htm\">Divers Instruction Sales and Service Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Divers Underwater Works.htm\">Divers Underwater Works</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dock Builders and Services.htm\">Dock Builders and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Donuts.htm\">Donuts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Drafting Services.htm\">Drafting Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dressmakers Alterations.htm\">Dressmakers Alterations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Driving Auto School.htm\">Driving Auto School</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Driving Instruction School.htm\">Driving Instruction School</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Drug Abuse and Addiction Information and Treatment Centers.htm\">Drug Abuse and Addiction Information and Treatment Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Drug Stores.htm\">Drug Stores</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dry Cleaners.htm\">Dry Cleaners</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Dry Wall Contractors.htm\">Dry Wall Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Duct Cleaning Heating Air Conditioning Etc.htm\">Duct Cleaning Heating Air Conditioning Etc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Duty Free Shops.htm\">Duty Free Shops</a><br>\n"; 


echo" </td>\n";
echo" <td width=\"250\" valign=\"top\" style=\"font-size:9px\">\n";


echo" <a href=\"cq.php?c=$c&q=Ear Piercing Service.htm\">Ear Piercing Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Eating Disorder Information and Treatment Centers.htm\">Eating Disorder Information and Treatment Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Economic Development Agencies.htm\">Economic Development Agencies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Educational and Learning Centers.htm\">Educational and Learning Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Elected Government Representatives.htm\">Elected Government Representatives</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Electric Contractors.htm\">Electric Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Electrolysis Treatments.htm\">Electrolysis Treatments</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Embroidery.htm\">Embroidery</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Emergency Services.htm\">Emergency Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Employment Agencies.htm\">Employment Agencies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Employment Agencies Temporary.htm\">Employment Agencies Temporary</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Employment Consultants.htm\">Employment Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Employment Training Svc.htm\">Employment Training Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Energy Conservation Products and Svc.htm\">Energy Conservation Products and Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Engineers.htm\">Engineers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Entertainers and Entertainment.htm\">Entertainers and Entertainment</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Entertainment Adult.htm\">Entertainment Adult</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Entertainment Agencies and Bureaus.htm\">Entertainment Agencies and Bureaus</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Environmental and Ecological Consultants.htm\">Environmental and Ecological Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Environmental and Ecological Products.htm\">Environmental and Ecological Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Environmental Conservation and Ecological Organizations.htm\">Environmental Conservation and Ecological Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Environmental Control Systems.htm\">Environmental Control Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Equestrian Services.htm\">Equestrian Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Equipment Leasing.htm\">Equipment Leasing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Equipment Rental and Service.htm\">Equipment Rental and Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Escort Service.htm\">Escort Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Estate Planning and Administration.htm\">Estate Planning and Administration</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Events Planning.htm\">Events Planning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Excavating Contractors.htm\">Excavating Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Exercise and Physical Fitness Equip.htm\">Exercise and Physical Fitness Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Eyewear.htm\">Eyewear</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Farm Equip and Supls.htm\">Farm Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Farm Supls And Feed.htm\">Farm Supls And Feed</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Farmers Markets.htm\">Farmers Markets</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Financial Management and Consulting.htm\">Financial Management and Consulting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Financial Services.htm\">Financial Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fire Alarm Systems.htm\">Fire Alarm Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fire Safety Svc.htm\">Fire Safety Svc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Firearms.htm\">Firearms</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=First Nations Organizations.htm\">First Nations Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fish Hatcheries and Farms.htm\">Fish Hatcheries and Farms</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fish Markets.htm\">Fish Markets</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fishermens Supls-Fishing Tackle Dealers.htm\">Fishermens Supls-Fishing Tackle Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fishery Consultants.htm\">Fishery Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fishing and Hunting Lodges.htm\">Fishing and Hunting Lodges</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fishing and Hunting-Accessories-Whol and Mfrs.htm\">Fishing and Hunting-Accessories-Whol and Mfrs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fishing Guides Charters and Parties.htm\">Fishing Guides Charters and Parties</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Florist Shops.htm\">Florist Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Formal Wear Rental.htm\">Formal Wear Rental</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Funeral Planning Services.htm\">Funeral Planning Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Fur and Clothing Storage.htm\">Fur and Clothing Storage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Furnace Cleaning and Repairing.htm\">Furnace Cleaning and Repairing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Furniture.htm\">Furniture</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Futons and Accessories.htm\">Futons and Accessories</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Games and Game Supls.htm\">Games and Game Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Garage Doors and Openers  Sales and Repair.htm\">Garage Doors and Openers  Sales and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Garden and Lawn Equip and Supls.htm\">Garden and Lawn Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Gemologists.htm\">Gemologists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Geologists.htm\">Geologists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Go Karts and Tracks.htm\">Go Karts and Tracks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Gold Silver and Platinum Buyers and Sellers.htm\">Gold Silver and Platinum Buyers and Sellers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Cars and Carts.htm\">Golf Cars and Carts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Club Private.htm\">Golf Club Private</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Courses.htm\">Golf Courses</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Courses Miniature and Adventure.htm\">Golf Courses Miniature and Adventure</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Driving and Practice Ranges.htm\">Golf Driving and Practice Ranges</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Golf Instructions.htm\">Golf Instructions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Gps Navigation Systems and Services.htm\">Gps Navigation Systems and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Graphic Designers.htm\">Graphic Designers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Guns and Gunsmiths.htm\">Guns and Gunsmiths</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hair Removal.htm\">Hair Removal</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Harley-Davidson Motorcycles.htm\">Harley-Davidson Motorcycles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hazardous Materials and Waste Services.htm\">Hazardous Materials and Waste Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Health and Diet Food Products.htm\">Health and Diet Food Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Heating and Air Conditioning Contractors.htm\">Heating and Air Conditioning Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Helicopter Service and Transport.htm\">Helicopter Service and Transport</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Helium Gas.htm\">Helium Gas</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hemp Products.htm\">Hemp Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Herb Shops.htm\">Herb Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hockey Arenas and Schools.htm\">Hockey Arenas and Schools</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hockey Clubs.htm\">Hockey Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Holistic Health Services.htm\">Holistic Health Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Home and Garden Products.htm\">Home and Garden Products</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Homeopathy.htm\">Homeopathy</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Horse Riding Lessons.htm\">Horse Riding Lessons</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hotels and Motels.htm\">Hotels and Motels</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=House Cleaning.htm\">House Cleaning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=House Rentals.htm\">House Rentals</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=House Watching and Sitting.htm\">House Watching and Sitting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Human Resources.htm\">Human Resources</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hunting and Fishing Outfitters.htm\">Hunting and Fishing Outfitters</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Hunting and Fishing Supls and Equip.htm\">Hunting and Fishing Supls and Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Importers.htm\">Importers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Insurance.htm\">Insurance</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Insurance Agents and Brokers.htm\">Insurance Agents and Brokers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Interior Decorators and Designers.htm\">Interior Decorators and Designers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Irrigation Systems and Equip.htm\">Irrigation Systems and Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Jewelers.htm\">Jewelers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Karaoke Equip - Sales and Rental.htm\">Karaoke Equip - Sales and Rental</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Knives.htm\">Knives</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Laser Vision Correction.htm\">Laser Vision Correction</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Lawn Service.htm\">Lawn Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Legal Consultants.htm\">Legal Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Libraries.htm\">Libraries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Limousine Services.htm\">Limousine Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Liquidators.htm\">Liquidators</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Liquor Dispensing Equip Sales and Service.htm\">Liquor Dispensing Equip Sales and Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Liquor Retail.htm\">Liquor Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Loans Personal.htm\">Loans Personal</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Locks and Locksmiths.htm\">Locks and Locksmiths</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Lawn and Garden Sprinkler Systems.htm\">Lawn and Garden Sprinkler Systems</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Log Homes.htm\">Log Homes</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Lounges and Bars.htm\">Lounges and Bars</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Lumber.htm\">Lumber</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Lions Clubs.htm\">Lions Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Libraries Public.htm\">Libraries Public</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Mailboxes Retail.htm\">Mailboxes Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Manicures and Pedicures.htm\">Manicures and Pedicures</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Marble and Granite.htm\">Marble and Granite</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Marina.htm\">Marina</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Martial Arts.htm\">Martial Arts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Massage Therapy and Therapists.htm\">Massage Therapy and Therapists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Mini Storage.htm\">Mini Storage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Money Transfer Service.htm\">Money Transfer Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Mortgage Brokers.htm\">Mortgage Brokers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Mortgage Companies.htm\">Mortgage Companies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Mortgage Services.htm\">Mortgage Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Motels and Hotels.htm\">Motels and Hotels</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Motorcycles.htm\">Motorcycles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Movie Theaters.htm\">Movie Theaters</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Moving and Storage.htm\">Moving and Storage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Martial Arts and Self Defense Equip and Supls.htm\">Martial Arts and Self Defense Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Motorcycles and Mini Bikes Supls and Parts.htm\">Motorcycles and Mini Bikes Supls and Parts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Motorcycles and Motor Scooters Renting and Leasing.htm\">Motorcycles and Motor Scooters Renting and Leasing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Martial Arts and Self Defense Instruction.htm\">Martial Arts and Self Defense Instruction</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Museums.htm\">Museums</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Musicians.htm\">Musicians</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Nail Salons and Services.htm\">Nail Salons and Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Nanny Services.htm\">Nanny Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Night Clubs.htm\">Night Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Nurseries Plants and Trees.htm\">Nurseries Plants and Trees</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Nutrition Consultants.htm\">Nutrition Consultants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Occupational Therapy.htm\">Occupational Therapy</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Oil and Gas Companies.htm\">Oil and Gas Companies</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Paintball Games Equip and Supls.htm\">Paintball Games Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Parks and Recreation.htm\">Parks and Recreation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Party and Event Equip and Supls.htm\">Party and Event Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Party and Event Planning.htm\">Party and Event Planning</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Pawn Broker and Shops.htm\">Pawn Broker and Shops</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Pet Grooming and Boarding.htm\">Pet Grooming and Boarding</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Photo and Picture Restoration.htm\">Photo and Picture Restoration</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Photographers Passport and Identification.htm\">Photographers Passport and Identification</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Photographers Weddings.htm\">Photographers Weddings</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Physical Fitness Centers.htm\">Physical Fitness Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Piano and Organs.htm\">Piano and Organs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Pool Contractors.htm\">Pool Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Post Offices.htm\">Post Offices</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Publishers.htm\">Publishers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Plumbing and Heating Contractors.htm\">Plumbing and Heating Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Pubs.htm\">Pubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Radio Broadcasting Companies and Stations.htm\">Radio Broadcasting Companies and Stations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Raft Trips and Tours.htm\">Raft Trips and Tours</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Real Estate.htm\">Real Estate</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Real Estate Brokers and Agents.htm\">Real Estate Brokers and Agents</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Recreation Centers.htm\">Recreation Centers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Recreational Vehicles and Camper Storage.htm\">Recreational Vehicles and Camper Storage</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Recreational and Commercial Vehicles.htm\">Recreational and Commercial Vehicles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Rental Agencies Property.htm\">Rental Agencies Property</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ranges and Ovens Wholesale and Mfrs.htm\">Ranges and Ovens Wholesale and Mfrs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Resorts.htm\">Resorts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Restaurants.htm\">Restaurants</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Rock Climbing and Rappelling.htm\">Rock Climbing and Rappelling</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School - Massage Therapy.htm\">School - Massage Therapy</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Business and Vocational Aircraft.htm\">School Business and Vocational Aircraft</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Business and Vocational Correspondence.htm\">School Business and Vocational Correspondence</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Colleges and Universities.htm\">School Colleges and Universities</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Fine Arts.htm\">School Fine Arts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Hairdressing.htm\">School Hairdressing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Hairstylists.htm\">School Hairstylists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School High and Preparatory.htm\">School High and Preparatory</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Industrial and Technical and Trade.htm\">School Industrial and Technical and Trade</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Preschool and Kindergarten.htm\">School Preschool and Kindergarten</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Secondary and Elementary.htm\">School Secondary and Elementary</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Speed Reading.htm\">School Speed Reading</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School Supls and Equip Retail.htm\">School Supls and Equip Retail</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=School With Special Academic Education.htm\">School With Special Academic Education</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Schools High.htm\">Schools High</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Scuba Diving.htm\">Scuba Diving</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Second Hand Stores and Dealers.htm\">Second Hand Stores and Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Security Guard and Patrol Services.htm\">Security Guard and Patrol Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Septic Tanks Cleaning and Pumping.htm\">Septic Tanks Cleaning and Pumping</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Shopping Centers and Malls.htm\">Shopping Centers and Malls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Siding Contractors.htm\">Siding Contractors</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sightseeing Tours and Attractions.htm\">Sightseeing Tours and Attractions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skateboards and Inline Skates.htm\">Skateboards and Inline Skates</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skates Sharpening and Repairing.htm\">Skates Sharpening and Repairing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skating Equip and Supls.htm\">Skating Equip and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skating Instruction.htm\">Skating Instruction</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skating Rinks.htm\">Skating Rinks</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ski and Snowboard Instructions.htm\">Ski and Snowboard Instructions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ski Centers and Ski Resorts.htm\">Ski Centers and Ski Resorts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ski Clubs and Organizations.htm\">Ski Clubs and Organizations</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ski Equip and Supls Sales and Rental.htm\">Ski Equip and Supls Sales and Rental</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Skylights and Solariums.htm\">Skylights and Solariums</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snow Plowing and Removal Service.htm\">Snow Plowing and Removal Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snow Removal Equip.htm\">Snow Removal Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snowblowers.htm\">Snowblowers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snowboard Equip.htm\">Snowboard Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snowmobile Centers and Resorts.htm\">Snowmobile Centers and Resorts</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Snowmobiles.htm\">Snowmobiles</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Social Workers.htm\">Social Workers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Secretarial Services.htm\">Secretarial Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Security Control Equip and Systems and Monitoring.htm\">Security Control Equip and Systems and Monitoring</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Solariums Sales and Service.htm\">Solariums Sales and Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sound Proofing.htm\">Sound Proofing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sound Systems and Equip.htm\">Sound Systems and Equip</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Spas Beauty and Day.htm\">Spas Beauty and Day</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Spas Saunas Hot Tubs and Whirlpools.htm\">Spas Saunas Hot Tubs and Whirlpools</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sporting Goods.htm\">Sporting Goods</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sports Bars.htm\">Sports Bars</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sports Cards and Memorabilia.htm\">Sports Cards and Memorabilia</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sprinklers Garden and Lawn Systems Equip Parts and Supls.htm\">Sprinklers Garden and Lawn Systems Equip Parts and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Surveyors Land.htm\">Surveyors Land</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Shipping Local and Overseas.htm\">Shipping Local and Overseas</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Stables.htm\">Stables</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Sandblasting.htm\">Sandblasting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Satellite Television Equip and Systems Service and Repair.htm\">Satellite Television Equip and Systems Service and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Stadiums Coliseums Arenas and Athletic Fields.htm\">Stadiums Coliseums Arenas and Athletic Fields</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Storage Self Service.htm\">Storage Self Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Stoves Wood Gas Coal Etc.htm\">Stoves Wood Gas Coal Etc</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Supermarkets.htm\">Supermarkets</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Swimming Pools Public.htm\">Swimming Pools Public</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tanning Salon.htm\">Tanning Salon</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tattoos.htm\">Tattoos</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tax Services.htm\">Tax Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Taxicabs and Transportation Service.htm\">Taxicabs and Transportation Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Taxidermists.htm\">Taxidermists</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Telephones Cellular Dealers.htm\">Telephones Cellular Dealers</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tennis Clubs.htm\">Tennis Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tents and Awnings.htm\">Tents and Awnings</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Ticket Sales Events.htm\">Ticket Sales Events</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tires.htm\">Tires</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tennis Courts Public.htm\">Tennis Courts Public</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tutoring Service.htm\">Tutoring Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tourist Attractions.htm\">Tourist Attractions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tourists Information and Attractions.htm\">Tourists Information and Attractions</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Towing Services.htm\">Towing Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tree Services.htm\">Tree Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Tuxedos Rental and Sales.htm\">Tuxedos Rental and Sales</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Vacation Homes Rentals.htm\">Vacation Homes Rentals</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Vacation Time Share.htm\">Vacation Time Share</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Vans and Trucks Customizing.htm\">Vans and Trucks Customizing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Veterinarians and Clinics.htm\">Veterinarians and Clinics</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Video Equip Installation Service and Repair.htm\">Video Equip Installation Service and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Video Conferencing.htm\">Video Conferencing</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Video Equip Sales and Rentals.htm\">Video Equip Sales and Rentals</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Video Games.htm\">Video Games</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Vitamins and Food Supplements.htm\">Vitamins and Food Supplements</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Watches Service and Repair.htm\">Watches Service and Repair</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Water Softening and Conditioning Equip Service and Supls.htm\">Water Softening and Conditioning Equip Service and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Watercraft.htm\">Watercraft</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Web Site Design.htm\">Web Site Design</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Weddings.htm\">Weddings</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Weed Control Service.htm\">Weed Control Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Weight Control Services.htm\">Weight Control Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Water Treatment Systems Equip Service and Supls.htm\">Water Treatment Systems Equip Service and Supls</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Window Glass Coating and Tinting.htm\">Window Glass Coating and Tinting</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Welding Services.htm\">Welding Services</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Wheel Alignment Frame and Axle Service.htm\">Wheel Alignment Frame and Axle Service</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Window Tinting Automotive and Residential.htm\">Window Tinting Automotive and Residential</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Windows Repair Replacement Installation.htm\">Windows Repair Replacement Installation</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Wineries.htm\">Wineries</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Wireless Communications.htm\">Wireless Communications</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Yoga Instruction and Therapy.htm\">Yoga Instruction and Therapy</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Youth Organizations Centers and Clubs.htm\">Youth Organizations Centers and Clubs</a><br>\n"; 
echo" <a href=\"cq.php?c=$c&q=Zoos.htm\">Zoos</a><br>\n"; 
?>
</td></tr></table><br>

<hr align="center" width="800px" size="1px" color="#000000">

<div align="center">
      <table align="center" border="0" width="800" cellspacing="0" cellpadding="2">
  <tr>
    <td width="800px" valign="top" colspan="5">
<b><font face="Verdana" size="2">&nbsp; More Look2 Business Directories:</font></b><br /><a href="http://www.look2vancouver.com">Vancouver Business</a>|<a href="http://www.look2victoria.com">Victoria Business</a>|<a href="http://www.look2britishcolumbia.com">BC Business Search</a></td>
  </tr>
  <tr>
    
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2fortcollins.com">Fort Collins Colorado</a> <br />
  <a href="http://www.look2indianapolis.com">Indianapolis Indiana</a><br />
  <a href="http://www.look2portland.com">Portland Oregon</a><br />
  <a href="http://www.look2spokane.com">Spokane Washington</a><br />
  <a href="http://www.look2lasvegas.com">Las Vegas Nevada</a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2mesa.com">Mesa Arizona</a><br />
  <a href="http://www.look2chandler.com">Chandler Arizona</a><br />
  <a href="http://www.look2tucson.com">Tucson Arizona</a><br />
  <a href="http://www.look2albuquerque.com">Albuquerque NM </a><br />
  <a href="http://www.look2raleigh.com">Raleigh NC </a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2henderson.com">Henderson Nevada</a><br />
  <a href="http://www.look2oregon.com">Oregon</a><br />
  <a href="http://www.look2newmexico.com">New Mexico</a><br />
  <a href="http://www.look2utah.com">Utah</a><br />
  <a href="http://www.look2washington.com">Washington State</a><br /></font>
        </td>
  <td width="200" valign="top"><font size="1">
  <a href="http://www.look2phoenix.com">Phoenix Arizona</a><br />
  <a href="http://www.look2charlotte.net">Charlotte NC</a><br /> 
  <a href="http://www.look2omaha.com">Omaha Nebraska </a><br />
  <a href="http://www.look2reno.com">Reno Nevada </a><br /> 
  <a href="http://www.look2glendale.com">Glendale Arizona</a><br /></font>
  </td>
  </tr>
</table>
</div>
<!-- Start of StatCounter Code -->
<script type="text/javascript">
var sc_project=2815785; 
var sc_invisible=0; 
var sc_partition=28; 
var sc_security="f8c91d69"; 
</script>

<script type="text/javascript" src="http://www.statcounter.com/counter/counter_xhtml.js"></script><noscript><div class="statcounter"><a class="statcounter" href="http://www.statcounter.com/"><img class="statcounter" src="http://c29.statcounter.com/2815785/0/f8c91d69/0/" alt="hit counter code" /></a></div></noscript>
<!-- End of StatCounter Code -->
 
<div id="footer">
Copyright (c) 2006-2008 All Rights Reserved - Look2 Yellowpages - <a href="http://www.look2northwestterritories.com/privacypolicy.html">Privacy Policy</a>
</div>
</div>
</div>
</center>
</body>
</html>