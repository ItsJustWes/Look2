<?php
    $DATABASE_SERVER = ':/var/lib/mysql/mysql.sock';
    $DATABASE_NAME   = 'nwt_nwt';
    $DATABASE_USER   = 'nwt_dub';
    $DATABASE_PASSWORD = 'gabe0810';
?>
