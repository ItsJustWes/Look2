
<html>	 
<head>	
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">	
 <title>Northwest Territories Business</title> 
<meta name="keywords" content="Northwest Territories business, Northwest Territories canada, Northwest Territories, canada business, Northwest Territories business directory, Northwest Territories business search">

<meta name="description" content="Northwest Territories business directory featuring addresses, phone numbers and maps of local business in the Northwest Territories Province of Canada"> 
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
<meta http-equiv="Content-Language" content="en-us">
<link rel="stylesheet" href="/dub.css" type="text/css"/>

<script language="JavaScript">
function blockError(){return true;}
window.onerror = blockError;
</script>

         

  <SCRIPT LANGUAGE="JavaScript">function selecturl(s) 

{

  var gourl = s.options[s.selectedIndex].value;



  if ((gourl != null) && (gourl != "") )

  {

    window.top.location.href = gourl;

  }

}

</SCRIPT>


</head>

<body>
<center>

<div id="wrap">
	<div id="header">
      <img src="/look2yellowpages1.jpg" align="left" alt="Northwest Territories business">
  <br />
      <h1><strong>Northwest Territories</strong></h1>
	  
	</div>
	<div id="content">	
  
   
<div align="center">
<font face="Verdana" size="2" color="#000000"><b>Northwest Territories Business Directory</b>:</font>

<form style="margin: 0px" action="q.php" method=get> 
<input name="q" type="text" value="" size="31">
<INPUT TYPE=submit value="Search" class="current">
</form>

<br>
</div>




<div id="tablespecial" align="center">

    <table width="800px valign="top" align="center">
  <tr>
    <td width="100%"><b><font face="Verdana" size="2">Search by City in Northwest Territories</font></b>	</td>
	</tr>
	</table>
	
   <table width="800px valign="top" align="center">
  <tr>
        <td valign="top">
	<a href="city.php?c=Yellowknife">Yellowknife</a> | <a href="city.php?c=Hay River">Hay River</a> | <a href="city.php?c=Fort Smith">Fort Smith</a> | <a href="city.php?c=Inuvik">Inuvik</a> | <a href="city.php?c=Fort Simpson">Fort Simpson</a>
	  </td>
  </tr>
   </table>
<hr align="center" width="800px" size="1px" color="#000000">

      <table border="0" width="800" cellspacing="0" cellpadding="2" >
  <tr>
    <td width="800px" valign="top" colspan="5">
<b><font face="Verdana" size="2">&nbsp; Northwest Territories popular searches:&nbsp;&nbsp; </font>
      <a style="text-decoration: none" href="categories.php">
      <font color="#800000">All Categories</font></a></b>	  	  </td>
  </tr>
  <tr>
    
   <td width="200" valign="top">
  <a href="Auto Dealers Used Cars.htm">Auto Dealers Used Cars</a><br> 
  <a href="Beer and Wine Stores.htm">Beer and Wine Stores</a><br> 
  <a href="Body Art and Piercing.htm">Body Art and Piercing</a><br> 
      </td>
    <td width="200" valign="top">

  <a href="Cafe and Restaurant.htm">Cafe and Restaurant</a><br> 
  <a href="Canoes and Kayaks Sales and Rentals.htm">Canoes and Kayaks Sales and Rentals</a><br> 
  <a href="Charters and Tours.htm">Charters and Tours</a><br>     </td>
    <td width="200" valign="top">
  <a href="Coffee Houses and Cafes.htm">Coffee Houses and Cafes</a><br> 
  <a href="Computer Sales and Services.htm">Computer Sales and Services</a><br>
  <a href="Florist Shops.htm">Florist Shops</a><br>    

  </td>
  <td width="200" valign="top">
   

  <a href="Hotels and Motels.htm">Hotels and Motels</a><br> 
  <a href="Massage Therapy and Therapists.htm">Massage Therapy and Therapists</a><br> 
  <a href="Parks and Recreation.htm">Parks and Recreation</a><br>
 </td>
      </tr>
</table>
</div>

<center>
<script type="text/javascript"><!--
google_ad_client = "pub-1757895371029345";
google_ad_width = 728;
google_ad_height = 90;
google_ad_format = "728x90_as";
google_ad_type = "text";
//2007-02-27: look2#800000banner
google_ad_channel = "7041940911";
google_color_border = "ffffff";
google_color_bg = "ffffff";
google_color_link = "800000";
google_color_text = "000000";
google_color_url = "000000";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>






<hr align="center" width="800px" size="1px" color="#000000">


<table width="800">
  <tr>
<td width="400px" align="center" valign="top">

<iframe marginheight="0" marginwidth="0" name="wxButtonFrame" id="wxButtonFrame" height="60" src="http://btn.weather.ca/weatherbuttons/template1.php?placeCode=CANT0032&category0=Cities&containerWidth=398&	btnNo=7829&backgroundColor=clouds&multipleCity=0&citySearch=0&celsiusF=C" align="top" frameborder="0" width="398" scrolling="no"></iframe>



<br />
<?php
$XMLFILE = "http://rss.cbc.ca/lineup/canada-north.xml";
$TEMPLATE = "http://www.look2northwestterritories.com/otherRSS.html";
$MAXITEMS = "10";
include("rss2html.php");
?>
<br />

</td>
<td width="400px" align="center" valign="top">

<?php
$XMLFILE = "http://rss.canada.com/get/?F75";
$TEMPLATE = "http://www.look2northwestterritories.com/news.html";
$MAXITEMS = "10";
include("rss2html.php");
?></td></tr></table>
<hr align="center" width="800px" size="1px" color="#000000">

<div align="center">
      <table align="center" border="0" width="800" cellspacing="0" cellpadding="2">
  <tr>
    <td width="800px" valign="top" colspan="5">
<b><font face="Verdana" size="2">&nbsp; More Look2 Business Directories:</font></b><br />
</td></tr>
<tr>
<td width="200" valign="top"><font size="1">
  
  <a href="http://www.look2vancouver.com">Vancouver BC</a><br />
  <a href="http://www.look2victoria.com">Victoria BC</a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2britishcolumbia.com">British Columbia</a> <br />
  <a href="http://www.look2alberta.com">Alberta</a><br />
  <a href="http://www.look2yukon.com">Yukon Territory</a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2saskatchewan.com">Saskatchewan</a><br />
  <a href="http://www.look2novascotia.com">Nova Scotia</a><br />
  <a href="http://www.look2newbrunswick.com">New Brunswick</a><br /></font>
        </td>
  <td width="200" valign="top"><font size="1">
  <a href="http://www.look2newfoundland.com">Newfoundland</a><br />
  <a href="http://www.look2quebec.com">Quebec</a><br /><a href="http://www.princeedwardisland.com">Prince Edward Island</a><br /></font>
  </td>
  </tr>
  <tr>
    
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2fortcollins.com">Fort Collins Colorado</a> <br />
  <a href="http://www.look2indianapolis.com">Indianapolis Indiana</a><br />
  <a href="http://www.look2portland.com">Portland Oregon</a><br />
  <a href="http://www.look2spokane.com">Spokane Washington</a><br />
  <a href="http://www.look2lasvegas.com">Las Vegas Nevada</a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2mesa.com">Mesa Arizona</a><br />
  <a href="http://www.look2chandler.com">Chandler Arizona</a><br />
  <a href="http://www.look2tucson.com">Tucson Arizona</a><br />
  <a href="http://www.look2albuquerque.com">Albuquerque NM </a><br />
  <a href="http://www.look2raleigh.com">Raleigh NC </a><br /></font>
       </td>
    <td width="200" valign="top"><font size="1">
  <a href="http://www.look2henderson.com">Henderson Nevada</a><br />
  <a href="http://www.look2oregon.com">Oregon</a><br />
  <a href="http://www.look2newmexico.com">New Mexico</a><br />
  <a href="http://www.look2utah.com">Utah</a><br />
  <a href="http://www.look2washington.com">Washington State</a><br />
  <a href="http://www.look2minnesota.com">Minnesota</a><br /></font>
        </td>
  <td width="200" valign="top"><font size="1">
  <a href="http://www.look2phoenix.com">Phoenix Arizona</a><br />
  <a href="http://www.look2charlotte.net">Charlotte NC</a><br /> 
  <a href="http://www.look2omaha.com">Omaha Nebraska </a><br />
  <a href="http://www.look2reno.com">Reno Nevada </a><br /> 
  <a href="http://www.look2glendale.com">Glendale Arizona</a><br /></font>
  </td>
  </tr>
</table>
</div>

<!-- Start of StatCounter Code -->
<script type="text/javascript">
var sc_project=2815785; 
var sc_invisible=0; 
var sc_partition=28; 
var sc_security="f8c91d69"; 
</script>

<script type="text/javascript" src="http://www.statcounter.com/counter/counter_xhtml.js"></script><noscript><div class="statcounter"><a class="statcounter" href="http://www.statcounter.com/"><img class="statcounter" src="http://c29.statcounter.com/2815785/0/f8c91d69/0/" alt="hit counter code" /></a></div></noscript>
<!-- End of StatCounter Code -->
<div id="footer">
Copyright (c) 2006-2008 All Rights Reserved - Look2 Yellowpages - <a href="http://www.look2northwestterritories.com/privacypolicy.html">Privacy Policy</a></div>
</div>
</div>
</center>
</body>
</html>