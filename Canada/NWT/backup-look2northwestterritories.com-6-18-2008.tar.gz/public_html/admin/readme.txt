Place these files into a folder such as admin. It would be wise to secure this folder.

Edit the db.php file and enter your database information.

These scripts are assuming that your Table Name is "List" and your fields are:
Name, Contact, Address, City, State, Zip, Telephone, Fax, Web, Email, Keywords1, Keywords1, Description